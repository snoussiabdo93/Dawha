<?php
namespace WP_Simple_Iconfonts\Extractor;

/**
 * Icomoon (app version) extractor provider.
 *
 * @link https://icomoon.io/app
 */
class Icomoon_App_Extractor extends Icomoon_Extractor implements Editable {
	// ...
}
