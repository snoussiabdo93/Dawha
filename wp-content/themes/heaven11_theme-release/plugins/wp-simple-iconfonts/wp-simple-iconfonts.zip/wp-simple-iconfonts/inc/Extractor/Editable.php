<?php
namespace WP_Simple_Iconfonts\Extractor;

interface Editable {
	// ...
}
